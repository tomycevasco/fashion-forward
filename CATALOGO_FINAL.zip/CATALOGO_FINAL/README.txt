CATÁLOGO DE PRODUCTOS - ESTRUCTURA

/imagenes/
  190 fotos recortadas (solo la prenda, sin texto), nombradas así:
  {ARCHIVO_ORIGEN}_{numero}.jpeg
  Ej: CARTERAS_FURLA_15.jpeg, ROPA_LIUJO_42.jpeg

/catalogo.json
  Archivo único con TODOS los productos (183 productos), cada uno con:
    - marca: FURLA | LIU JO | BALLY
    - seccion: ARTICULOS | CARTERAS | ROPA | ZAPATOS
    - categoria: tipo de prenda agrupado (ej: WALLET, BAG, DRESS, HEELS...)
    - codigo: código del producto (puede ser null si no estaba visible)
    - tipo: texto tal cual decía la slide (puede repetir la categoria)
    - color: color/variante (puede ser null)
    - precio: precio en formato "$XXX.000"
    - talle: talles disponibles si aplica (solo ropa y calzado)
    - imagen: nombre del archivo de imagen correspondiente en /imagenes/

/json_por_marca/
  Los mismos datos separados en 6 archivos por marca/sección, agrupados por categoría,
  por si preferís procesarlos por separado.

NOTA: Se detectaron algunos posibles errores tipográficos en el catálogo original
(ej "COSS OVER" en vez de "CROSS OVER", "LEATHE BAG" en vez de "LEATHER BAG").
Se transcribieron tal cual decía el original, sin corregir.
